const testController = (req,res)=>{
    res.status(200).send("SUCCESS");
}

module.exports = {testController}