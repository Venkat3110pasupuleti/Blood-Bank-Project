export const userMenu = [
    {
        name: 'Inventory',
        path: '/',
        icon: 'fa-solid fa-cubes'
    },
    {
        name: 'Donars',
        path:'/donar',
        icon: 'fa-solid fa-hand-holding-medical'
    },
    {
        name: "Hospitals",
        path:"/hospital",
        icon: "fa-solid fa-truck-medical"
    },
    {
        name: "Organisations",
        path:"/organisation",
        icon: "fa-solid fa-building-ngo"
    },
]